﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSwitch : MonoBehaviour
{

    public Camera a_Camera;
    public Camera b_Camera;
    public Camera c_Camera;

    // Start is called before the first frame update
    void Start()
    {
        a_Camera.enabled = true;
        b_Camera.enabled = false;
        c_Camera.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("ac_Trigger"))
        {
            a_Camera.enabled = !a_Camera.enabled;
            c_Camera.enabled = !c_Camera.enabled;
        }
        if (other.gameObject.CompareTag("bc_Trigger"))
        {
            b_Camera.enabled = !b_Camera.enabled;
            c_Camera.enabled = !c_Camera.enabled;
        }

    }
}
