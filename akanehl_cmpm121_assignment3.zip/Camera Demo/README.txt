This project was made by Aaron Kanehl and submitted 2/5/19. It satisfies the requirements of CMPM 121 assignment 3. 

CONTROLS: 
W: Move Forward	
A: Move Left
S: Move Backward
D: Move Right

F: Trigger Flashlight

The first room gives a security camera like effect, using the LookAt method, and the hallway gives a top down tracking move, that is locked along the x axis. The last room switches to a cinematic shot with baked lights that light the room corners. 

KNOWN NEEDED FIXES
---------------------------------------------------------
Lighting could be improved, need to mess with values more and tweak some issues with the lighting, figure out dynamic lighting without 'bounce shadows?'