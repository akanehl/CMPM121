This game was created to satisfy the requirements of Assignment 1 for Computational Media 121: Game Technologies.

Controls: 
W: Move forward
A: Move Left
S: Move Backwards
D: Move Right

X: Rotate along 'x' axis
Y: Rotate along 'y' axis
Z: Rotate along 'z' axis

R: Turn the object Red
G: Turn the object Green
B: Turn the Object Blue

Q: Increase the Objects scale by a factor of 2
E: Decrease the Objects scale by a factor of 2

C: Change to a cube
F: Change to a sphere
V: Change to a capsule

T: Turn Gravity on (Unique modification)

O: Save current object modifications
P: Load object Modifications from the last save. 

KNOWN BUGS/ERRORS
----------------------------------
When changing shapes, modifications do not carry over.

When saving/loading, If shapes switch, saving/loading will not work. 

Upon start, all 3 shapes are visible, but once a shape is changed the others are set to inactive.

(Please try and give half credit/points where you can, most of it is partially working, just not with the shapes...)

