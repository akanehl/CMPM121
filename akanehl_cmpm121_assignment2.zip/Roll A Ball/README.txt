This game was created to satisfy the requirements for Assignment 2 in Computational Media 121. 

Note: This game is a modified version of the Unity tutorial Roll a Ball, which I completed last year in a different version of Unity, then modified to a) Work with this current version of Unity, and b) satisfy the rest of the requirements, namely a camera switch component and a Jump button. 

Controls:

W: Roll Forward
A: Roll Left
S: Roll Backwards
D: Roll Right

Space: Flutter (Can jump multiple times)

C: Switch cameras from Third to First, and First to Third. 

KNOWN BUGS
--------------------------------------------------------------
First person camera does not move left and right, and will only face forward, from the initial movement, but does follow the ball as you roll. 

The ball can jump through the plane ramp, due to the nature of it being a plane. 

UNIQUE MODIFICATION
--------------------------------------------------------------
The addition of a jump mechanic as well as the spinning collectible items satisfy the unique modification requirement as set forth by the Assignment definition

